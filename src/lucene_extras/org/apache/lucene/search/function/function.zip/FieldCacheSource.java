package org.apache.lucene.search.function;

import org.apache.lucene.search.FieldCache;

/**
 * A base class for ValueSource implementations that retrieve values for
 * a single field from the {@link org.apache.lucene.search.FieldCache}.
 *
 * @author yonik
 * @version $Id: FieldCacheSource.java,v 1.1 2005/11/22 05:23:20 yonik Exp $
 */
public abstract class FieldCacheSource extends ValueSource {
  protected String field;
  protected FieldCache cache = FieldCache.DEFAULT;

  public FieldCacheSource(String field) {
    this.field=field;
  }

  public void setFieldCache(FieldCache cache) {
    this.cache = cache;
  }

  public FieldCache getFieldCache() {
    return cache;
  }

  public String description() {
    return field;
  }

  public boolean equals(Object o) {
    if (!(o instanceof FieldCacheSource)) return false;
    FieldCacheSource other = (FieldCacheSource)o;
    return this.field.equals(other.field)
           && this.cache == other.cache;
  }

  public int hashCode() {
    return cache.hashCode() + field.hashCode();
  };

}
