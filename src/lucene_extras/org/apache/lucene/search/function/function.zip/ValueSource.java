package org.apache.lucene.search.function;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.function.DocValues;

import java.io.IOException;
import java.io.Serializable;

/**
 * Instantiates {@link org.apache.lucene.search.function.DocValues} for a particular reader.
 * <br>
 * Often used when creating a {@link FunctionQuery}.
 *
 * @author yonik
 * @version $Id: ValueSource.java,v 1.2 2005/11/30 19:31:01 yonik Exp $
 */
public abstract class ValueSource implements Serializable {

  public abstract DocValues getValues(IndexReader reader) throws IOException;

  public abstract boolean equals(Object o);

  public abstract int hashCode();

  /** description of field, used in explain() */
  public abstract String description();

  public String toString() {
    return getClass().getName() + ":" + description();
  }

}
